# SVT Transport Dashboard

Sri Venkateshwara Transports - Dashboard Application built with React and Vite.

## Setup & Installation

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Preview production build locally
npm run preview
```

## Project Structure

```
├── src/
│   ├── App.jsx           # Main application component
│   └── main.jsx          # React entry point
├── index.html            # HTML template
├── package.json          # Dependencies and scripts
├── vite.config.js        # Vite configuration
└── vercel.json          # Vercel deployment configuration
```

## Technologies

- **React** - UI library
- **Vite** - Build tool and dev server
- **Recharts** - Data visualization
- **Vercel** - Hosting platform

## Deployment to Vercel

### Prerequisites
- GitHub repository with your code pushed
- Vercel account

### Steps

1. **Connect Repository**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Select your GitHub repository

2. **Configure Build Settings**
   - Framework: Auto-detected (Vite)
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`

3. **Deploy**
   - Click "Deploy"
   - Wait for build completion
   - Your site will be live at `your-project.vercel.app`

## Troubleshooting

### Build Fails with "package.json not found"
- Ensure `package.json` is in the root directory
- Commit and push all files to Git

### Build Cache Issues
- In Vercel Dashboard → Deployments
- Click the menu (⋯) and select "Redeploy"
- Check "Skip build cache" option

### Module Not Found Errors
- Clear node_modules: `rm -rf node_modules`
- Reinstall: `npm install`
- Clear npm cache: `npm cache clean --force`

## Environment Variables

If needed, add environment variables:
1. Go to Vercel Project Settings → Environment Variables
2. Add your variables
3. Redeploy

## License

Private project
